Have java and derby installed 
Its a CLI program so yea its basic
